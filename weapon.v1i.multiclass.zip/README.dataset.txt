# weapon > 2024-11-18 7:12pm
https://universe.roboflow.com/finalyrproject-ui6lv/weapon-dqdqe

Provided by a Roboflow user
License: CC BY 4.0

