# Security-System > 2024-10-02 2:01pm
https://universe.roboflow.com/finalyrproject-ui6lv/security-system-ymhxl

Provided by a Roboflow user
License: CC BY 4.0

